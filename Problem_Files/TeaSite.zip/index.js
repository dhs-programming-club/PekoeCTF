const express = require('express');
const app = express();
const path = require('path');
var bodyParser = require("body-parser");
const port = process.env.PORT || 8000

app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/views');
app.set('view engine', 'html');

app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.urlencoded({ extended: true }));

app.post('/signin', function(req, res) {
  var username = req.body.username;
  var password = req.body.password;
  if(username === "guest"){
    res.send("The password is P3k03");
  }
  else if(username === "admin" && password == "P3k03"){
    res.send("<body style='background: #303030'><p style='color: #fbea40'>himalayan orange</p></body>");
  }
  else{
    res.send("Wrong username and/or password");
  }
});

app.get('/', function(req, res){
  res.sendFile(path.join(__dirname+'/views/index.html'));
});

app.listen(port, function(){
  console.log("Running on port : " + port);
});
