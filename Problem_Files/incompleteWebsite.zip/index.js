const express = require('express');
const app = express();
const path = require('path');
var bodyParser = require("body-parser");
const port = process.env.PORT || 8000

app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/views');
app.set('view engine', 'html');

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function(req, res){
  res.render("index.html");
}).listen(port);

app.get('/home', function(req, res){
  res.send(`
    <title>/home</title>
    <u>To Do</u>
    <br/>
    <ul>
      <li>Add Styling</li>
      <li>Add actual contents</li>
      <li>Get Buttons working.  probably gonna just copy some code off of stack overflow</li>
    </ul>
    <h1><u>Home</u></h1>
    <article>
      <h2>This is a header</h2>
      <p>
        This is a paragraph about stuff.  <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ">This is a link to a website</a>
      </p>
      <p>
        <button>Demo Button 1</button>
        <br/>
        <button>Demo Button 2</button>
      </p>
    </article>
  `);
});

app.get('/about', function(req, res){
  res.send(`
    <title>/about</title>
    <h2>
      <u>About Me</u>
    </h2>
    <br/>
    <figure>
      <img src="img/Sal.jpg" style="width: 400px; width: 200px;"></img>
      <figcaption>Picture of Me</figcaption>
    </figure>
    <p>
      [About me paragraph]
    </p>
    <ul>
      To Do :
      <li>Styling</li>
      <li>paragraph content</li>
    </ul>
    `);
});

app.get('/contact', function(req, res){
  res.send(`
    <title>/contact</title>
    <link rel="stylesheet" href="css/main.css"/>
    <h2><u>Contact Info</u></h2>
    <h3>This page has all my contact info</h3>
    Email - example@example.com
    <br/>
    Phone Number - 123-456-7890

  `);
});

app.get('/flag', function(req, res){
  res.send(`
    <title>/flag</title>
    pekoe{mango_fruit_74a9b2}
  `);
})

console.log("Running on port : " + port);
