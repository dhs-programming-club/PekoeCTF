const express = require('express');
const app = express();
const path = require('path');
var bodyParser = require("body-parser");
const port = process.env.PORT || 8000

app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/views');
app.set('view engine', 'html');

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function(req, res){
  res.render('index.html');
}).listen(port);

app.get('/home', function(req, res){
  res.render('home.html');
});

app.get('/about', function(req, res){
  res.render('about.html');
});

app.get('/contact', function(req, res){
  res.render('contact.html');
});

app.post('/flag', function(req, res){
  res.send('pekoe{orange_passion_fruit_2abdd4}');
})

console.log("Running on port : " + port);
