
function openSignIn(){
	signIn = document.getElementById("signIn");
	getComputedStyle(signIn, null).display == "none" ? signIn.style.display = "block" : signIn.style.display = "none";
}
