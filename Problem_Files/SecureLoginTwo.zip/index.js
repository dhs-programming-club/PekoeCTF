const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const port = process.env.PORT || 8000;

app.set('view engine', 'pug');
app.set('views', './views');

app.use(express.static('public'));
app.use(cookieParser());
app.use(bodyParser.urlencoded({
  extended: true
}));

app.listen(port, () => {
  console.log(`Running on port ${port}`);
});

app.get('/', (req, res) => {
  res.cookie('permissions', 'JTdCJTIyYWRtaW4lMjIlM0FmYWxzZSU3RA==');
  res.render('index');
});

app.post('/login', (req, res) => {
  if(req.body.username == 'admin' && req.body.password == 'admin'){
    if(req.cookies.permissions == 'JTdCJTIyYWRtaW4lMjIlM0F0cnVlJTdE'){
      res.send('pekoe{mango_black_de89cb}');
    }
    else{
      res.send('Access denied');
    }
  }
  else{
    res.send('Invalid username or password');
  }
});
