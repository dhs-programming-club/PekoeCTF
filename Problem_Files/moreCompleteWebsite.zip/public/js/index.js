
var xhttp = new XMLHttpRequest();

// I'll do the rest later
