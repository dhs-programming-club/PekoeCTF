const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const port = process.env.PORT || 8000;

app.set('view engine', 'pug');
app.set('views', './views');

app.use(express.static('public'));
app.use(bodyParser.urlencoded({
  extended: true
}));

app.listen(port, () => {
  console.log(`Running on port ${port}`);
});

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/login', (req, res) => {
  if(req.body.username == 'admin' && req.body.password == 'admin'){
    res.send('pekoe{citrus_blend_fb6f28}');
  }
  else{
    res.send('Invalid username or password');
  }
});
