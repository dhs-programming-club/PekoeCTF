To do this problem run "node index.js" in cmd/terminal then in your browser go to 127.0. 0.1:8000
That's all, just don't look in the index.js file cause it will give away the flag.  Once this problem
is on the server index.js should not be accessible to who ever does the problem.